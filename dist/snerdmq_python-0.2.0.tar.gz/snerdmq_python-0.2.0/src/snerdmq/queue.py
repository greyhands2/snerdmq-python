import asyncio
import json
import os
import signal
import sys
from typing import Callable, Awaitable, Dict, Any, Optional
import contextvars
from aiohttp import web

# Store the current task ID for yield_progress
_current_task_id = contextvars.ContextVar('current_task_id', default=None)


class SnerdQueue:
    def __init__(self, binary_path: Optional[str] = None, storage_path: Optional[str] = None):
        self.handlers: Dict[str, Callable[[Any], Awaitable[None]]] = {}
        self.process: Optional[asyncio.subprocess.Process] = None
        self.is_shutting_down = False
        self.pending_enqueues: Dict[str, asyncio.Future] = {}
        self.progress_listeners = set()
        self.dashboard_runner = None
        
        if not binary_path:
            package_dir = os.path.dirname(os.path.abspath(__file__))
            ext = '.exe' if os.name == 'nt' else ''
            binary_path = os.path.join(package_dir, 'bin', f'snerdmq{ext}')

        if not os.path.exists(binary_path):
            raise FileNotFoundError(f"[Snerd] Binary not found at {binary_path}. Please run 'snerdmq-install' or provide binary_path.")

        self.binary_path = binary_path
        self.storage_path = storage_path

        # Handle graceful shutdown signals
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                asyncio.get_running_loop().add_signal_handler(sig, self.shutdown)
            except NotImplementedError:
                pass # Windows does not support add_signal_handler easily

    async def start_listening(self):
        """Starts the rust daemon and the event loop to listen to its output."""
        args = [self.storage_path] if self.storage_path else []
        self.process = await asyncio.create_subprocess_exec(
            self.binary_path, *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        if not self.process.stdout or not self.process.stderr:
            raise RuntimeError("[Snerd] Failed to establish standard I/O pipes.")

        # Re-send all registrations in case we are reconnecting
        for task_type in self.handlers.keys():
            await self._send({"action": "register", "task_type": task_type})

        # Run stdout and stderr readers concurrently
        await asyncio.gather(
            self._read_stdout(),
            self._read_stderr()
        )

    async def _read_stdout(self):
        assert self.process and self.process.stdout
        while not self.is_shutting_down:
            line = await self.process.stdout.readline()
            if not line:
                break
            line_str = line.decode().strip()
            if not line_str:
                continue

            try:
                msg = json.loads(line_str)
                # Dispatch handler without blocking the read loop
                asyncio.create_task(self._handle_engine_message(msg))
            except json.JSONDecodeError:
                pass

        if not self.is_shutting_down:
            print("[Snerd] Engine process terminated unexpectedly.", file=sys.stderr)

    async def _read_stderr(self):
        assert self.process and self.process.stderr
        while not self.is_shutting_down:
            line = await self.process.stderr.readline()
            if not line:
                break
            print(f"[Snerd Engine Error]: {line.decode().strip()}", file=sys.stderr)

    async def _handle_engine_message(self, msg: dict):
        if msg.get('action') == 'ack':
            task_id = msg.get('task_id')
            if task_id and task_id in self.pending_enqueues:
                self.pending_enqueues[task_id].set_result(None)
                del self.pending_enqueues[task_id]
        elif msg.get('action') == 'error':
            task_id = msg.get('task_id')
            if task_id and task_id in self.pending_enqueues:
                self.pending_enqueues[task_id].set_exception(RuntimeError(msg.get('message')))
                del self.pending_enqueues[task_id]
            else:
                print(f"[Snerd] Error from engine: {msg.get('message')}", file=sys.stderr)
        elif msg.get('action') == 'execute':
            task_type = msg.get('task_type')
            task_id = msg.get('task_id')
            task_data = msg.get('task_data')
            
            if isinstance(task_data, str):
                try:
                    task_data = json.loads(task_data)
                except json.JSONDecodeError:
                    pass

            handler = self.handlers.get(task_type)
            if not handler:
                await self._send({'action': 'result', 'task_id': task_id, 'status': 'error', 'error_msg': 'No handler registered.'})
                return

            try:
                _current_task_id.set(task_id)
                await handler(task_data)
                await self._send({'action': 'result', 'task_id': task_id, 'status': 'success'})
            except Exception as e:
                await self._send({'action': 'result', 'task_id': task_id, 'status': 'error', 'error_msg': str(e)})

        elif msg.get('action') == 'progress':
            for ws in list(self.progress_listeners):
                try:
                    # msg is already a dict, just forward it
                    asyncio.create_task(ws.send_json(msg))
                except Exception:
                    self.progress_listeners.discard(ws)

        elif msg.get('action') == 'max_retries_reached':
            print(f"[Snerd] Dead Letter Queue: Task {msg.get('task_id')} ({msg.get('task_type')}) permanently failed.", file=sys.stderr)

    async def _send(self, msg: dict):
        if self.process and self.process.stdin and not self.is_shutting_down:
            self.process.stdin.write((json.dumps(msg) + '\n').encode())
            await self.process.stdin.drain()

    def register_handler(self, task_type: str, handler: Callable[[Any], Awaitable[None]]):
        """Registers an async function to handle a specific task type."""
        self.handlers[task_type] = handler
        if self.process:
            asyncio.create_task(self._send({"action": "register", "task_type": task_type}))

    async def enqueue(self, task_id: str, task_type: str, data: Any, max_retries: int = 3, retry_after_hours: float = 0.0, rate_limit_group: Optional[str] = None, max_per_minute: Optional[int] = None, auto_dedupe: Optional[bool] = None, urgency_score: Optional[float] = None):
        """Enqueues a new background job."""
        if not self.process:
            raise RuntimeError("[Snerd] Cannot enqueue task: Queue is not running. Call start_listening() first.")
        
        payload = {
            'action': 'enqueue',
            'task_id': task_id,
            'task_type': task_type,
            'task_data': json.dumps(data),
            'max_retries': max_retries,
            'retry_after_hours': retry_after_hours
        }

        if rate_limit_group is not None:
            payload['rate_limit_group'] = rate_limit_group
        if max_per_minute is not None:
            payload['max_per_minute'] = max_per_minute
        if auto_dedupe is not None:
            payload['auto_dedupe'] = auto_dedupe
        if urgency_score is not None:
            payload['urgency_score'] = urgency_score

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_enqueues[task_id] = future
        await self._send(payload)
        await future

    def shutdown(self):
        """Gracefully kills the Rust daemon."""
        if self.is_shutting_down:
            return
        self.is_shutting_down = True
        if self.process:
            try:
                self.process.terminate()
            except ProcessLookupError:
                pass


    def yield_progress(self, data: Any):
        """Yields a progress update for the currently executing task."""
        task_id = _current_task_id.get()
        if not task_id:
            raise RuntimeError("[Snerd] yield_progress must be called within a task handler context.")
        
        # We can't easily make a sync network call if the process stdin writing is async.
        # But wait, self._send is async. yield_progress should ideally be sync if users call it from sync code.
        # However, SnerdQueue handlers are async: `Callable[[Any], Awaitable[None]]`.
        # So we can just make yield_progress async.
        # But wait! Node and Ruby are sync. Python can be async.
        pass

    async def yield_progress_async(self, data: Any):
        task_id = _current_task_id.get()
        if not task_id:
            raise RuntimeError("[Snerd] yield_progress must be called within a task handler context.")
        await self._send({
            'action': 'progress',
            'task_id': task_id,
            'data': data
        })

    def yield_progress(self, data: Any):
        """Yields progress. If inside an event loop, schedules the send."""
        task_id = _current_task_id.get()
        if not task_id:
            raise RuntimeError("[Snerd] yield_progress must be called within a task handler context.")
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._send({
                'action': 'progress',
                'task_id': task_id,
                'data': data
            }))
        except RuntimeError:
            pass

    def start_dashboard(self, port: int = 8080):
        """Starts the embedded dashboard and API server."""
        async def handle_ws(request):
            ws = web.WebSocketResponse()
            await ws.prepare(request)
            self.progress_listeners.add(ws)
            try:
                async for msg in ws:
                    pass
            finally:
                self.progress_listeners.discard(ws)
            return ws

        async def handle_stats(request):
            enqueued = 0
            processed = 0
            failed = 0
            
            storage_dir = self.storage_path or './.snerdata'
            tasks_file = os.path.join(storage_dir, 'tasks', 'tasks.log')
            if os.path.exists(tasks_file):
                with open(tasks_file, 'r') as f:
                    for line in f:
                        if not line.strip(): continue
                        try:
                            t = json.loads(line)
                            enqueued += 1
                            if t.get('deletedAt'):
                                if t.get('lastJobError'):
                                    failed += 1
                                else:
                                    processed += 1
                        except json.JSONDecodeError:
                            pass
            return web.json_response({'enqueued': enqueued, 'processed': processed, 'failed': failed}, headers={'Access-Control-Allow-Origin': '*'})

        async def handle_tasks(request):
            tasks_map = {}
            storage_dir = self.storage_path or './.snerdata'
            tasks_file = os.path.join(storage_dir, 'tasks', 'tasks.log')
            if os.path.exists(tasks_file):
                with open(tasks_file, 'r') as f:
                    for line in f:
                        if not line.strip(): continue
                        try:
                            t = json.loads(line)
                            if 'taskId' in t:
                                tasks_map[t['taskId']] = t
                        except json.JSONDecodeError:
                            pass
            
            res = []
            for t in tasks_map.values():
                if t.get('deletedAt'):
                    status = 'failed' if t.get('lastJobError') else 'completed'
                else:
                    status = 'failed' if t.get('lastJobError') else 'queued'
                res.append({
                    'id': t['taskId'],
                    'type': t['taskType'],
                    'status': status,
                    'progress': 0,
                    'retryCount': t.get('retryCount', 0),
                    'maxRetries': t.get('maxRetries', 3),
                    'retryAfterTime': t.get('retryAfterTime')
                })
            
            return web.json_response(res, headers={'Access-Control-Allow-Origin': '*'})

        async def handle_index(request):
            # Try to find static/index.html
            static_file = os.path.join(os.path.dirname(__file__), '..', '..', 'static', 'index.html')
            if not os.path.exists(static_file):
                static_file = os.path.join(os.getcwd(), 'static', 'index.html')
                
            if os.path.exists(static_file):
                return web.FileResponse(static_file)
            return web.Response(text="Dashboard UI not found in static folder.", status=404)

        async def start_app():
            app = web.Application()
            app.router.add_get('/', handle_index)
            app.router.add_get('/api/stats', handle_stats)
            app.router.add_get('/api/tasks', handle_tasks)
            app.router.add_get('/ws', handle_ws)
            
            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, '0.0.0.0', port)
            await site.start()
            self.dashboard_runner = runner
            print(f"[Snerd] Dashboard running on http://localhost:{port}")

        loop = asyncio.get_event_loop()
        loop.create_task(start_app())
